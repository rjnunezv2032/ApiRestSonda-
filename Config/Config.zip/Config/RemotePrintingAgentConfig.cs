﻿using Sonda.Core.RemotePrintingAgent.Model.Entities;
using System.Collections.Generic;

namespace Sonda.Core.RemotePrintingAgent.Config
{
    /// <summary>
    /// Clase de Configuracion de Agente de Impresion.
    /// </summary>
    public class RemotePrintingAgentConfig : IRemotePrintingAgentConfig
    {
        /// <summary>
        /// Url Base del socket de servicio de impresion remota.
        /// </summary>
        public string RemotePrintingServiceBaseUrl { get; set; }

        ///// <summary>Version del servicio socket</summary>
        //public string RemotePrintingServiceVersion { get; set; }
        ///// <summary>Controlador de peticiones del socket</summary>
        //public string RemotePrintingServiceController { get; set; }
        /// <summary>
        /// Url del Servicio de Notificaciones de Sonda
        /// </summary>
        //public string NotificationsURL { get; set; }

        /// <summary>
        /// Tamaño del buffer de recepcion de datos
        /// </summary>
        public int ReceiveBuffersSize { get; set; }

        /// <summary>
        /// Tiempo en milisegundos
        /// </summary>
        public int RefreshRate { get; set; }

        /// <summary>
        /// Directorio temporal para archivos descargados.
        /// </summary>
        public string TemporaryFolder { get; set; }

        /// <summary>
        /// Informacion del Agente.
        /// </summary>
        public AgentInfo AgentInfo { get; set; }

        /// <summary>
        /// Url del servicio (completa)
        /// </summary>
        public string RemotePrintingServiceURL
        {
            get
            {
                //return $"{RemotePrintingServiceBaseUrl}/{RemotePrintingServiceVersion}/{RemotePrintingServiceController}";
                return RemotePrintingServiceBaseUrl;
            }
        }

        /// <summary>Lista de impresoras registradas en el servicio de impresion remota<summary>
        public List<LocalPrinter> PrintersInfo { get; set; }

        /// <summary>
        /// Fuente por defecto para impresion de texto plano.
        /// </summary>
        public DefaultRawPrintFont DefaultRawPrintFont { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public RemotePrintingAgentConfig()
        {
            AgentInfo = new AgentInfo();
            PrintersInfo = new List<LocalPrinter>();
            DefaultRawPrintFont = new();
        }
    }
}